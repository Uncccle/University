public class new1{
	public static void main (String[] args){
		int a=1;
		byte b = 127;
		short c = 22222;
		long d = 22222222222222222L;
		float e = 2.6666666666F;
		float f = 2.6666666666F;
		char s= 'a' ;
		System.out.println(s+1);
	}
}

