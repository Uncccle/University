#include <stdio.h>


void main()
{
	int a=5;
	int b=6;
	int t;
	
	t=a;
	a=b;
	b=t;
	
	printf("a=%d b=%d",a, b);
	return 0;
	
	/*  ���ϸ�ֵ */
	//total += 5;
	// == total = total + 5
	
	// total += (sum + 100) /2
	// total = total + (sum + 100) /2
	
	// total *= sum + 12
	// total = total * (total +12)
	
	//total /= 12+4
	// total = total / (12+4)
	
	/* �����ݼ������  */
	// count++
	// count += 1
	// count = count + 1
	
	//��֮-- 
	 
	 // a=10
	 // a++
	 // a=a+1
	 // a=11
	 
	 // ++a
	 // += 1+a
	 // 12
	
	
 } 
