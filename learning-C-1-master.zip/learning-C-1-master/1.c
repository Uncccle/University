#include <stdio.h>

int main()
{
	printf("HelloWorld\n");
	return 0;
	
} 
