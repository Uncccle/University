package firstclass;

import java.util.Scanner;

public class a {

    public static void main(String [] ah ){

        int x = 4;
        int y = ++x;
        System.out.println(y);



        }


    }

