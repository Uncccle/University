package firstclass;

public class AverageOfClass {

    public static void main(String args[]){
        int k = 4 ;
        ++k;
        System.out.println(k);
    }
}
