package firstclass;

import java.awt.print.Pageable;
import java.util.Scanner;

public class customer {

    public static void main(String args[]){
//        int a =1;
//        while()



    }
}
