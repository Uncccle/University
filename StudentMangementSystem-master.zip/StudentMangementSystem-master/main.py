from mangersystem import *

if __name__== "__main__":
    student_system=StudentManager()
    student_system.run()