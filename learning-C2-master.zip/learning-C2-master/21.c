#include <stdio.h>

void main()
{
	
	int count=100;
	while (count>=0){
		
		printf("%d\n",count); 
		count--;
	} 
	printf("���䣡");
	
}
