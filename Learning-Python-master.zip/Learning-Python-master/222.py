blog_writing = {"ID":11}
z=input()
for i in  blog_writing:
    if z == "ID":


        print("a")
    else:
        print("2")