def xx():
    print("sss")

def hhh():
    xx()
    print("xxxx")

uu=hhh()
print(uu)


#

a1 = 2
b =2



A=[DDD,]
B=A.length()
print(B)