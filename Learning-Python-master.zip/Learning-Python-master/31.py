#---------------------异常------------------------
#   需求： 尝试打开test.txt(r). 如果文件不存在，只写方式打开W


"""
try:
    可能发生错误的代码

except:
    发生错误的时候只写的代码

"""
# try:
#     open("test.txt", "r")
# except:
#     open("test.txt", "r")

#   异常类型

# #NameError
# print(num)

from b import age
name = "MrSun"
print(name,age)