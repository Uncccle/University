a="jdfhksdhfsdhf"





li = [1,2,3]
def Modify(li):
    li.append(4)
    print(li)
print(li)
Modify(li)
fn = Modify
print(fn)
fn(li)
print(li)
print(fn(li))


dic = {"name":"mrsun",'age':20}
print(dic['money'])