#-----------*改*------------

#   修改制定下标的数据
Name = ["hhh", "lll", "kakak"]
Name[0]="dsad"
print(Name)


#  逆序
#   列表.reverse()
Name1 = [1, 2, 3, 4, 5]
Name1.reverse()
print(Name1)


#   sort()
#   排序：升序、降序
#   默认是升序
#   列表.sort(reverse=True)
#   True=降序   False=升序
#    列表.sort()

Name2 = [1, 5, 7, 8, 3]
Name2.sort()
print(Name2)


