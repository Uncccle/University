#--------------------*判断*-------------

#   字符串序列.startswith(子串， 开始位置下标， 结束位置下标)
#   字符串序列判断字符串开头

C="This is your computer and your table"
print(C.startswith("This"))


#   字符串序列.endswith(子串， 开始位置下标， 结束位置下标)
#   字符串序列判断字符串结尾
print(C.endswith("e"))

