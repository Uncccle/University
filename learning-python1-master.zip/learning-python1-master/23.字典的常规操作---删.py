#-------------*删*---------


#   del 字典{}
dict1={"name":"Tom", "age":12, "gender":"male"}
del dict1["age"]
print(dict1)



#   字典.clear()
dict2={"name":"Tom", "age":12, "gender":"male"}
dict2.clear()
print(dict2)