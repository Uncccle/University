#-----for循环-------

a="dsfjnsd"
for i in a:
    print(i)

#---else---(在for函数当中也可以使用)-----------
# 当正常循环结束后，执行的代码。
b="金木水火土"
for i in b:
    print(i)
else:
    print("系统错误")

# break ----退出整个循环
# continue----退出本次循环，继续执行下一个重复执行的代码