#-------------*复制*---------


#   列表.copy()

Name = [1, 2, 3, 4, 5]
Name_1 = Name.copy()
print(Name_1)