#-----------*集合*------------

#   创建集合
A={1, 2, 3, 4}
B=set("d")

print(type(A))
print(type(B))

C={"a", "b", "c"}
#   用这种形式的集合时，如果要写成set()的这种形式，需要：
D=set("abc")#这样写



#   空集
#   只能用set()

E=set()
print(type(E))

