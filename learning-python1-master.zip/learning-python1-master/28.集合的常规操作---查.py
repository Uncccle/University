#-------------*查*--------------

#   in: 判断数据在集合序列中
#   not in: 判断数据不在集合序列中


A={1, 2, 3, 4}
print(3 in A)
print(1 not in A)
#   返回的是布尔：True  False

