#---------------*列表的判断*-----------------

#---------判断是否存在-----



#--存在
#  in

A=[1, "aa", 23, "sad", 23, 1]
print("aa" in A)
#若存在，返回True,则False



#--不存在
#  not in
print("ee" not in A)
#若存在，返回True,则False