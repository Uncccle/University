#---------*元组的查找*--------

A=("ss", "ajh", 11, 1.1)



#--下标(索引)--
print(A[2])



#-----列表.index()
print(A.index(11))
#print(A.index("ds"))#不存在的就会报错


#---列表.count()
#   统计列表中的数据出现的次数

print(A.count(11))

#---len()--
#   统计列表中的数据个数
print(len(A))




