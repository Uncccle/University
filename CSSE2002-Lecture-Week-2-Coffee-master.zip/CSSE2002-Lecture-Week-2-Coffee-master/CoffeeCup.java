public class CoffeeCup {

    //一杯咖啡的容量
    public double amountOfCoffee;
    //一杯咖啡中的Espresso是多少（百分比）
    public double strengthOfCoffee;


    //构造函数
    public CoffeeCup(){

        amountOfCoffee = 0.0;
        strengthOfCoffee = 0.0;

    }

    //返回一杯咖啡的容量
    public double getAmountOfCoffee() {

        return amountOfCoffee;

    }

    //返回一杯的Espresso的纯度
    public double getStrengthOfCoffee() {

        return strengthOfCoffee;

    }

    //返回一杯咖啡中---咖啡因的量
    public double getEffectiveCaffeine(){

        /*
        * 根据文献可以知道：
        *               ------- 因为每25ml的Espresso中有100mg的咖啡因
        *
        * 所以我们要先算出一杯咖啡中,有多少Espresso：
        *     一杯咖啡 除以 25 = 一杯咖啡中Espresso的量  --- (amountOfCoffee / 25.0)
        *
        * 然后乘以100就可以算出一杯咖啡中咖啡因的总数了：
        *     一杯咖啡中Espresso的量 乘以 100mg = 一杯咖啡中咖啡因的量 --- (amountOfCoffee / 25.0 * strengthOfCoffee)
        *
        * 最后返回咖啡因的量
        * */

        return amountOfCoffee / 25.0 * strengthOfCoffee;

    }

    //加入自己喜爱的东西 （例如： 水、咖啡、牛奶）| 然后显示出它的容量和Espresso的纯度
    public void addToCup(CoffeeCup coffee){

        //根据自己的喜好制定加入新的咖啡的容量（毫升） --- 新的咖啡的容量（毫升） = 原本咖啡的容量 + 加入的咖啡容量
        double newAmount = amountOfCoffee + coffee.amountOfCoffee;

        //1000ml的咖啡 * Espresso的浓度10% = 100ml的espresso
        //Espresso的浓度 = 1000ml的咖啡 除以 100ml的espresso
        //根据自己的喜好制定加入新的咖啡中Espresso的浓度（百分比):
        //                          --- 新的Espresso的浓度（百分比） =  (旧的Espresso的量 + 加入的Espresso的量) / 新加入咖啡的容量
        //                                       ---  旧的Espresso的量 = 旧的咖啡量 * 旧的Espresso浓度
        //                                       ---  加入的Espresso的量 = 加入的咖啡量 * 加入的Espresso浓度
        double newStrength = (amountOfCoffee * strengthOfCoffee + coffee.amountOfCoffee * coffee.strengthOfCoffee) / newAmount;

        //一杯咖啡的容量 = 制定加入新的咖啡的容量
        amountOfCoffee = newAmount;

        //一杯咖啡的浓度 = 制定加入新的咖啡中Espresso的浓度
        strengthOfCoffee = newStrength;

    }

    //将两种不同的咖啡混合成一种新的咖啡种类，最后返回出新的咖啡
    //CoffeeCup是数据类型   coffee是加入咖啡的种类
    public CoffeeCup combineInNewCupWith(CoffeeCup coffee){

        //新建新的合成咖啡种类（对象）
        CoffeeCup newCup = new CoffeeCup();

        //新的合成咖啡的容量 = 旧的咖啡容量 + 要加入的咖啡容量
        newCup.amountOfCoffee = amountOfCoffee + coffee.amountOfCoffee;

        //新的合成咖啡的浓度 = （旧的咖啡的纯度 + 新的咖啡的纯度）除以 新的合成咖啡的容量
        newCup.strengthOfCoffee = (amountOfCoffee * strengthOfCoffee + coffee.amountOfCoffee * coffee.strengthOfCoffee) / newCup.amountOfCoffee;

        return newCup;
    }

    //加入Espresso（几勺）
    public void addEspressoToCup(int amountOfShots){

        //建立Espresso这个对象
        CoffeeCup Espresso = new CoffeeCup();

        //Espresso的量 = 勺量 * 25ml
        Espresso.amountOfCoffee = 25 * amountOfShots;

        //Espresso的浓度 = 100%
        Espresso.strengthOfCoffee = 100;

        //调用方法  addToCup(加入的Espresso)
        addToCup(Espresso);

    }

    //加入水的量
    public void addWaterToCup(double amountOfWater){

        //建立水这个对象
        CoffeeCup Water = new CoffeeCup();

        //水的量 = 你输入水的量
        Water.amountOfCoffee = amountOfCoffee;

        //水中Espresso浓度 = 0
        Water.strengthOfCoffee = 0;

        //调用方法 addToCup(加入的Water)
        addToCup(Water);

    }

    //加入牛奶的量
    public void addMilkToCup(double amountOfMilk){

        //建立牛奶这个对象
        CoffeeCup milk = new CoffeeCup();

        //牛奶的量 = 你输入的量
        milk.amountOfCoffee = amountOfMilk;

        //牛奶中Espresso的浓度 = 0
        milk.strengthOfCoffee = 0;

        //调用方法 addToCup(加入的Milk)
        addToCup(milk);
    }
    



}
