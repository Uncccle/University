public class main {

    public static void ShortBlack(){

        CoffeeCup ShortBlack = new CoffeeCup();
        ShortBlack.addEspressoToCup(10);
        ShortBlack.addWaterToCup(0);
        ShortBlack.addMilkToCup(0);

        System.out.println("--- Short Black ---");
        System.out.println("容量；" + ShortBlack.getStrengthOfCoffee() + "ml");
        System.out.println("Espresso 纯度：" + ShortBlack.strengthOfCoffee + "%");
        System.out.println("咖啡因含量：" + ShortBlack.getEffectiveCaffeine() + "mg");


    }

    public static void Americano(){

        CoffeeCup Americano =  new CoffeeCup();
        Americano.addEspressoToCup(1);
        Americano.addWaterToCup(75);
        Americano.addMilkToCup(0);

        System.out.println("--- Americano ---");
        System.out.println("容量；" + Americano.getStrengthOfCoffee() + "ml");
        System.out.println("Espresso 纯度：" + Americano.strengthOfCoffee + "%");
        System.out.println("咖啡因含量：" + Americano.getEffectiveCaffeine() + "mg");

    }

    public static void main(String[] args) {
        ShortBlack();
    }

}
